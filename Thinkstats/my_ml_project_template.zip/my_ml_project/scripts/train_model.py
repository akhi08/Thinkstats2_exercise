# Script to train ML model
